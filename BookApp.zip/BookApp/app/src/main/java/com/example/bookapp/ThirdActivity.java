package com.example.bookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ThirdActivity extends AppCompatActivity {

    private Button download_button_1;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_third);


            download_button_1 = findViewById(R.id.download_button_1);

            download_button_1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Your signup logic here
                        }
                    });

                    // Set OnClickListener for Read buttons
                    findViewById(R.id.download_button_1).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Handle click for Book 1
                            navigateToBookDetail();
                        }
                    });

                    findViewById(R.id.download_button_2).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Handle click for Book 2
                            navigateToBookDetail();
                        }
                    });

                    findViewById(R.id.download_button_3).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Handle click for Book 3
                            navigateToBookDetail();
                        }
                    });

                    // Set OnClickListener for Next Page button
                    findViewById(R.id.next_page_button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    });
                }

                private void navigateToBookDetail() {
                    // Create an Intent to navigate to the BookDetailActivity
                    Intent intent = new Intent(ThirdActivity.this, forthActivity.class);
                    startActivity(intent);
                }
            }



